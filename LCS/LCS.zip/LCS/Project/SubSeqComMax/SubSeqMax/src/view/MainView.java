/*
 *
 */
package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author server_x1
 */
public class MainView extends JFrame {

    public static final int WINDOW_WIDTH = 850;
    public static final int WINDOW_HEIGHT = 400;
    public static final String VERSION = "0.0";

    JPanel mainPanel,
           editPanel1,
           editPanel2,
           toolPanel;

    public MainView(FileSelectorView fileSelector1, FileSelectorView fileSelector2,
            FileContentView file1, FileContentView file2,
            ResultView result, ToolsView toolsView) {

        super("Subseqüência Comum Mais Longa v" + VERSION);

        init(fileSelector1, fileSelector2,
            file1, file2,
            result, toolsView);
    }

    private void init(FileSelectorView fileSelector1, FileSelectorView fileSelector2,
            FileContentView file1, FileContentView file2,
            ResultView result, ToolsView toolsView) {

        JPanel pnlNorth = new JPanel(new BorderLayout()),
               pnlCenter = new JPanel(new BorderLayout()),
               pnlSouth = new JPanel(new BorderLayout());

        mainPanel = new JPanel(new BorderLayout());
        editPanel1 = new JPanel(new BorderLayout());
        editPanel2 = new JPanel(new BorderLayout());
        toolPanel = new JPanel(new BorderLayout());

        pnlNorth.add(fileSelector1, BorderLayout.NORTH);
        pnlNorth.add(file1, BorderLayout.CENTER);
        pnlNorth.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        pnlNorth.setPreferredSize(new Dimension(700, 130));

        pnlCenter.add(fileSelector2, BorderLayout.NORTH);
        pnlCenter.add(file2, BorderLayout.CENTER);
        pnlCenter.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        pnlCenter.setPreferredSize(new Dimension(700, 130));

        pnlSouth.add(result, BorderLayout.CENTER);
        pnlSouth.setBorder(BorderFactory.createTitledBorder("Resultado"));
        pnlSouth.setPreferredSize(new Dimension(700, 110));

        editPanel1.add(pnlNorth, BorderLayout.NORTH);
        editPanel1.add(pnlCenter, BorderLayout.CENTER);
        editPanel1.add(pnlSouth, BorderLayout.SOUTH);

        toolPanel.add(toolsView, BorderLayout.CENTER);

        mainPanel.add(toolPanel, BorderLayout.WEST);
        mainPanel.add(editPanel1, BorderLayout.EAST);

        setContentPane(mainPanel);
        setSize(new Dimension(WINDOW_WIDTH, WINDOW_HEIGHT));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
    }
}
