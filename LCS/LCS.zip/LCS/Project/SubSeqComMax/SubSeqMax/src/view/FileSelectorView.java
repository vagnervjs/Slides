/*
 *
 */
package view;

import controller.FileSelectorViewController;
import java.awt.BorderLayout;
import javax.swing.*;

/**
 *
 * @author server_x1
 */
public class FileSelectorView extends JPanel {

    private JTextField tfdFilePath;

    private JButton btnOpen;

    public FileSelectorView(String name) {

        super(new BorderLayout());

        init(name);
    }

    private void init(String name) {

        JLabel lblTemp;

        lblTemp = new JLabel(name, JLabel.CENTER);
        lblTemp.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        tfdFilePath = new JTextField(30);

        btnOpen = new JButton("Abrir");

        add(lblTemp, BorderLayout.NORTH);
        add(tfdFilePath, BorderLayout.CENTER);
        add(btnOpen, BorderLayout.EAST);

        setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
    }

    public JButton getBtnOpen() {

        return btnOpen;
    }

    public JTextField getTfdFilePath() {

        return tfdFilePath;
    }

    public void setController(FileSelectorViewController controller) {

        btnOpen.addActionListener(controller);
    }
}
