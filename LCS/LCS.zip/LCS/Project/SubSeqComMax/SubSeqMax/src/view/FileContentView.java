/*
 *
 */
package view;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.*;

/**
 *
 * @author server_x1
 */
public class FileContentView extends JPanel {

    private JTextField epnFileContent;

    private String plainText = "";

    public FileContentView() {

        super(new BorderLayout());

        init();
    }

    private void init() {

        JPanel pnlTemp = new JPanel(new BorderLayout());

        epnFileContent = new JTextField();

        clear();

        pnlTemp.add(epnFileContent, BorderLayout.CENTER);

        setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1));

        add(pnlTemp, BorderLayout.CENTER);
    }

    public JTextField getEpnFileContent() {

        return epnFileContent;
    }

    public void setTextContent(String text) {

        epnFileContent.setText(text);
    }

    public void addLine(String line) {

        plainText += line + "\n";

        epnFileContent.setText(plainText);
    }

    public void showFormatedResult(String url) {
    }

    public void clear() {

        epnFileContent.setText("");
        plainText = "";
    }
}
