/*
 *
 */
package view;

import controller.MainController;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 *
 * @author server_x1
 */
public class ResultView extends JPanel {

    private JTextArea txaResult;

    private JScrollPane scroll;

    private ResultMatrixView matrixView;

    public ResultView() {

        super(new BorderLayout());

        init();
    }

    private void init() {

        txaResult = new JTextArea();

        txaResult.setText("");

        matrixView = new ResultMatrixView();

        scroll = new JScrollPane(txaResult);

        add(scroll, BorderLayout.CENTER);

        txaResult.setEditable(false);
    }

    public JTextArea getTxaResult() {

        return txaResult;
    }

    public void addResult(String result, String matrixNum, String matrixSym, int resNum) {

        matrixView.setContent("\n      --- [Matriz Numerada] ---\n\n" + matrixNum + "\n      --- [ Matriz Indicação ]---\n\n" + matrixSym);

        txaResult.setText(txaResult.getText() + "[ R " + resNum + " ] " + result + "\n");
    }

    public void clearResult() {

        txaResult.setText("");
        matrixView.clear();
    }

    public void showMatrixArea() {

        if (matrixView.isVisible()) {
            matrixView.setVisible(false);
        } else {
            matrixView.setVisible(true);
        }
    }
}
