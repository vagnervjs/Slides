/*
 *
 */
package view;

import controller.MainController;
import java.awt.Dimension;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import view.basic.VerticalFlowLayout;

/**
 *
 */
public class ToolsView extends JPanel {

    public static final int WINDOW_WIDTH = 150;
    public static final int WINDOW_HEIGHT = 650;

    private JButton btnExecute,
                    btnClear,
                    btnShowMatrix;

    public ToolsView() {

        super(new VerticalFlowLayout(VerticalFlowLayout.TOP));

        init();
    }

    private void init() {

        btnExecute = new JButton("Executar");
        btnClear = new JButton("Limpar");
        btnShowMatrix = new JButton("Matriz");

        setBorder(BorderFactory.createTitledBorder("Opções"));
        setPreferredSize(new Dimension(WINDOW_WIDTH, WINDOW_HEIGHT));

        add(btnExecute);
        add(btnShowMatrix);
        add(btnClear);
    }

    public JButton getBtnExecute() {

        return btnExecute;
    }

    public JButton getBtnShowMatrix() {

        return btnShowMatrix;
    }

    public JButton getBtnClear() {

        return btnClear;
    }

    public void setController(MainController controller) {

        btnExecute.addActionListener(controller);
        btnClear.addActionListener(controller);
        btnShowMatrix.addActionListener(controller);
    }
}
