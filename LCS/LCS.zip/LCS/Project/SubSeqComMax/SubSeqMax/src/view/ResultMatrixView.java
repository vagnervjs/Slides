/*
 *
 */
package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.*;

/**
 *
 * @author luiz
 */
public class ResultMatrixView extends JFrame {

    public static final int WINDOW_WIDTH = 350;
    public static final int WINDOW_HEIGHT = 350;

    private JPanel mainPanel;

    private JScrollPane scroll;

    private JTextArea matrix;

    public ResultMatrixView() {

        super("Matriz Resultado");

        init();
    }

    private void init() {

        mainPanel = new JPanel(new BorderLayout());

        matrix = new JTextArea();

        scroll = new JScrollPane(matrix);
        scroll.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        mainPanel.add(scroll, BorderLayout.CENTER);

        setContentPane(mainPanel);
        setSize(new Dimension(WINDOW_WIDTH, WINDOW_HEIGHT));
        setFont(new Font("Monospaced", Font.PLAIN, 12));
    }

    public void clear() {

        matrix.setText("");
    }

    public void setContent(String str) {

        matrix.setText(str);
    }

    public JTextArea getMatrizArea() {

        return matrix;
    }
}
