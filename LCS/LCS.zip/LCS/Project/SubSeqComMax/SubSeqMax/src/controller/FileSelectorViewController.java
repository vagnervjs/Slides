/*
 *
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import view.FileContentView;
import view.FileSelectorView;

/**
 *
 * @author server_x1
 */
public class FileSelectorViewController implements ActionListener {

    private FileContentView fileContentView;
    private FileSelectorView fileSelectorView;

    private FileNameExtensionFilter filterTxt;
    private JFileChooser fchFileChooser;

    public FileSelectorViewController(FileSelectorView fileSelectorView,
            FileContentView fileContentView) {

        this.fileSelectorView = fileSelectorView;
        this.fileContentView = fileContentView;

        filterTxt = new FileNameExtensionFilter(".txt", "txt");
        fchFileChooser = new JFileChooser();
        fchFileChooser.setFileFilter(filterTxt);
    }

    private void openFile(File file) {

        String line = "";
        BufferedReader fileBuffer;
        
        try {
            fileBuffer = new BufferedReader(new FileReader(file));
            fileContentView.clear();
            for (; (line = fileBuffer.readLine()) != null;) {
                fileContentView.addLine(line);
            }
            fileBuffer.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao carregar arquivo - " + file.getAbsolutePath());
        }
    }

    @Override
    public void actionPerformed(ActionEvent ae) {

        int returnVal = JFileChooser.CANCEL_OPTION;
        File file = null;

        if (ae.getSource().equals(fileSelectorView.getBtnOpen())) {
            if (fileSelectorView.getTfdFilePath().getText() != null &&
                    !fileSelectorView.getTfdFilePath().getText().isEmpty()) {
                file = new File(fileSelectorView.getTfdFilePath().getText());
            } else {
                returnVal = fchFileChooser.showSaveDialog(null);
                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    file = fchFileChooser.getSelectedFile();
                    fileSelectorView.getTfdFilePath().setText(file.getAbsolutePath());
                }
            }
            if (file != null) {
                openFile(file);
            } else if (returnVal != JFileChooser.CANCEL_OPTION) {
                JOptionPane.showMessageDialog(null, "Escolha um arquivo válido");
            }
        }
        
        fileSelectorView.getTfdFilePath().requestFocus();
    }
}
