/*
 *
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import model.CalcLCS;
import view.FileContentView;
import view.ResultView;
import view.ToolsView;

/**
 *
 * @author server_x1
 */
public class MainController implements ActionListener {

    private FileContentView fileContentView1,
                            fileContentView2;

    private ToolsView toolsView;

    private ResultView resultView;

    private CalcLCS calcLCS;

    private int numResult = 0;

    public MainController(ToolsView toolsView,
            FileContentView fileContentView1,
            FileContentView fileContentView2,
            FileSelectorViewController fileSelectorViewController1,
            FileSelectorViewController fileSelectorViewController2,
            ResultView resultView) {

        calcLCS = new CalcLCS();

        this.toolsView = toolsView;

        this.fileContentView1 = fileContentView1;
        this.fileContentView2 = fileContentView2;

        this.resultView = resultView;
    }

    @Override
    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource().equals(toolsView.getBtnExecute())) {
            String x = fileContentView1.getEpnFileContent().getText(),
                   y = fileContentView2.getEpnFileContent().getText();

            if (x == null || y == null ||
                    x.isEmpty() || y.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Parâmetros de entrada incorretos");
            } else {
                calcLCS.setStrings(x, y);
                calcLCS.execute();
                resultView.addResult(calcLCS.getStringResult() + ", " + calcLCS.getSizeMax(),
                        calcLCS.getNumMatrixResult(), calcLCS.getSymMatrixResult(),
                        ++numResult);
            }
        } else if (ae.getSource().equals(toolsView.getBtnClear())) {
            resultView.clearResult();
            fileContentView1.clear();
            fileContentView2.clear();
        } else if (ae.getSource().equals(toolsView.getBtnShowMatrix())) {
            resultView.showMatrixArea();
        }
    }
}
