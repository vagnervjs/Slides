/*
 *
 */
package model;

/**
 *
 * @author server_x1
 */
public class CalcLCS {

    private String s1 = "",
                   s2 = "";

    private char matrixSym[][];

    private int lengths[][],
                sizeMax = 0,
                lenWidth = 0,
                lenHeight = 0;

    private String result = "";

    public CalcLCS() {

    }

    public void setStrings(String s1, String s2) {

        this.s1 = s1.toLowerCase();
        this.s2 = s2.toLowerCase();
    }

    private void calcMatrix() {

        lenWidth = s1.length();
        lenHeight = s2.length();

        lengths = new int[lenHeight + 1][lenWidth + 1];
        matrixSym = new char[lenHeight + 1][lenWidth + 1];

        sizeMax = -1;

        for (int i = 1; i <= lenHeight; i++) {
            for (int j = 1; j <= lenWidth; j++) {
                if (s1.charAt(j - 1) == s2.charAt(i - 1)) {
                    lengths[i][j] = lengths[i - 1][j - 1] + 1;
                    matrixSym[i][j] = '▲';
                    if ((lengths[i - 1][j - 1] + 1) > sizeMax) {
                        sizeMax = lengths[i - 1][j - 1] + 1;
                    }
                } else {
                    if (lengths[i - 1][j] >= lengths[i][j - 1]) {
                        matrixSym[i][j] = '↑';
                        lengths[i][j] = lengths[i - 1][j];
                    } else {
                        matrixSym[i][j] = '←';
                        lengths[i][j] = lengths[i][j - 1];
                    }
                }
            }
        }
    }

    private void calcString() {

        result = "";

        for (int i = lenHeight; i > 0;) {
            for (int j = lenWidth; j > 0;) {
                if (matrixSym[i][j] == '▲') {
                    result += s1.charAt(j - 1);
                    i--;
                    j--;
                } else if (matrixSym[i][j] == '↑') {
                    i--;
                } else {
                    j--;
                }
            }
        }

        result = new StringBuffer(result).reverse().toString();
    }

    public void execute() {

        calcMatrix();
        calcString();
    }

    public String getStringResult() {

        return result;
    }

    public int getSizeMax() {

        return sizeMax;
    }

    public String getSymMatrixResult() {

        String stringMatrixResult = "   ";

        for (int i = 1; i <= lenHeight; i++) {
            for (int j = 1; j <= lenWidth; j++) {
                stringMatrixResult += String.valueOf(matrixSym[i][j]) + "  |  ";
            }
            stringMatrixResult += String.valueOf('\n');
            stringMatrixResult += "   ";
        }

        return stringMatrixResult;
    }

    public String getNumMatrixResult() {

        String stringMatrixResult = "   ";

        for (int i = 1; i <= lenHeight; i++) {
            for (int j = 1; j <= lenWidth; j++) {
                stringMatrixResult += String.valueOf(lengths[i][j]) + "  |  ";
            }
            stringMatrixResult += String.valueOf('\n');
            stringMatrixResult += "   ";
        }

        return stringMatrixResult;
    }
}