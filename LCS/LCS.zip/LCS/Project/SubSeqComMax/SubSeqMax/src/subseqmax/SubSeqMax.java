/*
 *
 */
package subseqmax;

import controller.FileSelectorViewController;
import controller.MainController;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.UIManager;
import view.*;

/**
 *
 * @author server_x1
 */
public class SubSeqMax {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        // Modifica o "tema" utilizado pela aplicação
        try {
            UIManager.setLookAndFeel(UIManager.getInstalledLookAndFeels()[3].getClassName());
            //SwingUtilities.updateComponentTreeUI(this);
        } catch (Exception ex) {
            Logger.getLogger(SubSeqMax.class.getName()).log(Level.SEVERE, null, ex);
        }

        FileSelectorView fileSelector1 = new FileSelectorView("Arquivo 1"),
                fileSelector2 = new FileSelectorView("Arquivo 2");

        FileContentView fileContent1 = new FileContentView(),
                fileContent2 = new FileContentView();

        FileSelectorViewController fileSelectorViewControl1 = new FileSelectorViewController(fileSelector1, fileContent1),
                fileSelectorViewControl2 = new FileSelectorViewController(fileSelector2, fileContent2);

        ToolsView toolsView = new ToolsView();

        ResultView result = new ResultView();

        MainController mainControl = new MainController(toolsView,
                fileContent1, fileContent2,
                fileSelectorViewControl1, fileSelectorViewControl2,
                result);

        toolsView.setController(mainControl);

        fileSelector1.setController(fileSelectorViewControl1);
        fileSelector2.setController(fileSelectorViewControl2);

        MainView mainView = new MainView(fileSelector1, fileSelector2, fileContent1, fileContent2, result, toolsView);

        mainView.setVisible(true);
    }
}
